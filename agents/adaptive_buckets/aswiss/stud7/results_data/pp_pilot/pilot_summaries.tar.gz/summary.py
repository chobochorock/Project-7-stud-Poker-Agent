# T9 table: paired Policy-LBR (2,000 pairs, 64 particles, same deals for every arm) at the epoch snapshots
import csv, json, os, sys
D = os.path.dirname(os.path.abspath(__file__))
arms = [("pp", "pp (parent start, assign now)"), ("pp_root", "pp, root start (before the budget fix)"), ("pp_root2", "pp, root start (default, budget fixed)"), ("pp_fill", "pp, assign by filling m"), ("pp_z35", "pp, z = 3.5"),
        ("k256", "k-means 256"), ("ctx", "context (no cards)")]
snaps = {5: 63000, 6: 127000, 7: 255000}
def ev(d, k, pol):
    f = f"{D}/eval_{d}_{k}_{pol}.json"
    if not os.path.exists(f) or os.path.getsize(f) == 0: return None
    return json.load(open(f))
def cpu(d, k):
    p = f"{D}/{d}/snapshots.csv"
    if not os.path.exists(p): return None
    for r in csv.DictReader(open(p)):
        if r["kind"] == "epoch" and int(r["epoch"]) == k: return float(r["train_cpu_seconds"]), int(r["buckets"])
    return None
print("| arm | roots | buckets | training CPU s | LBR average policy (± se) | ratio to k-means 256 | LBR current policy (± se) | ratio |")
print("|---|---:|---:|---:|---:|---:|---:|---:|")
for k, roots in snaps.items():
    base = {pol: ev("k256", k, pol) for pol in ("average", "current")}
    for d, name in arms:
        c = cpu(d, k)
        cells = []
        for pol in ("average", "current"):
            e = ev(d, k, pol)
            if e is None: cells += ["missing", ""]; continue
            b = base[pol]
            ratio = f"{e['lbr_ante'] / b['lbr_ante']:.2f}" if b and b["lbr_ante"] > 0 else ("n/a (baseline LBR <= 0)" if b else "missing baseline")
            cells += [f"{e['lbr_ante']:.3f} ± {e['lbr_se']:.3f}", ratio]
        print(f"| {name} | {roots:,} | {c[1] if c else '?':,} | {c[0] if c else float('nan'):.0f} | " + " | ".join(cells) + " |" if c else
              f"| {name} | {roots:,} | ? | ? | " + " | ".join(cells) + " |")
