# all pilot evaluation points -> tree_points.csv (t9: eval_<dir>_<k>_<policy>.json; tp_seeds: <arm>_s<seed>/eval.jsonl)
import csv, json, os, re, glob
rows = {}
def snap(d):
    p = f"{d}/snapshots.csv"
    return {int(r["epoch"]): (int(r["roots"]), int(r["buckets"]), float(r["train_cpu_seconds"])) for r in csv.DictReader(open(p)) if r["kind"] == "epoch"} if os.path.exists(p) else {}
for f in sorted(glob.glob("t9/eval_*.json")):
    m = re.fullmatch(r"eval_(.+)_(\d+)_(average|current)\.json", os.path.basename(f))
    if not m or os.path.getsize(f) == 0: continue
    d, k, pol = m.group(1), int(m.group(2)), m.group(3)
    if d in ("pp_root",): continue  # the run before the budget fix (kept in t9_table.md)
    ms = re.fullmatch(r"(.+)_s(\d)", d)
    arm, seed = (ms.group(1), int(ms.group(2))) if ms else (d, 1)
    s = snap(f"t9/{d}").get(k)
    if s is None: continue
    e = json.load(open(f))
    rows[(arm, seed, s[0], pol)] = (s[1], s[2], e["lbr_ante"], e["lbr_se"])
for d in sorted(glob.glob("tp_seeds/*_s[0-9]")):
    ms = re.fullmatch(r"(.+)_s(\d)", os.path.basename(d)); arm, seed = ms.group(1), int(ms.group(2))
    sn = {v[0]: v for v in snap(d).values()}
    for e in map(json.loads, open(f"{d}/eval.jsonl")):
        key = (arm, seed, e["roots"], e["policy"]); val = (sn[e["roots"]][1], sn[e["roots"]][2], e["lbr_ante"], e["lbr_se"])
        if key in rows and abs(rows[key][2] - val[2]) > 1e-9: print("MISMATCH", key, rows[key], val)
        rows[key] = val
names = {"tree_inh": "tree_inh01", "pp_root2": "pp_root", "pp": "pp_parent", "pp_inh": "pp_root_inh01", "pp_inh11": "pp_root_inh11"}
with open("tree_points.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["arm", "seed", "roots", "tables", "train_cpu_seconds", "policy", "lbr_ante", "lbr_se"])
    for (arm, seed, roots, pol), (tab, cpu, l, se) in sorted(rows.items(), key=lambda x: (names.get(x[0][0], x[0][0]), x[0][1], x[0][2], x[0][3])):
        w.writerow([names.get(arm, arm), seed, roots, tab, f"{cpu:.1f}", pol, f"{l:.4f}", f"{se:.4f}"])
print(len(rows), "rows")
