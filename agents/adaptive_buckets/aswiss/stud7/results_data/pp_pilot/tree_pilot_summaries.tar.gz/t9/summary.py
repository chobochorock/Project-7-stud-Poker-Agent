# Pilot table: Policy-LBR (2,000 pairs, 64 particles, the same deals for every arm) at the epoch snapshots (taken
# before the judgment of that epoch). An arm's row is printed at every budget its run reached; an evaluation that was
# not run is printed as "missing". The baseline (k-means 256) was evaluated at every budget.
import csv, json, os
D = os.path.dirname(os.path.abspath(__file__))
arms = [("pp", "pp, parent start"), ("pp_root2", "pp, root start (default)"), ("pp_inh", "pp, root start, inherit avg"),
        ("pp_fill", "pp, assign by filling m"), ("pp_z35", "pp, parent start, z = 3.5"),
        ("tree", "tree (default: min-leaf 1)"), ("tree_inh", "tree, inherit regret 0 + avg 1"),
        ("tree_ml4", "tree, min-leaf 4"), ("tree_ml8", "tree, min-leaf 8"), ("tree_cf", "tree, cross-fit"),
        ("tree_poker", "tree, poker features"), ("tree_ml8_poker", "tree, min-leaf 8 + poker"),
        ("tree_ml8_cf_poker", "tree, min-leaf 8 + cross-fit + poker"),
        ("tree_ml8_poker_b1", "tree, min-leaf 8 + poker, judgment budget 1.0"),
        ("tree_frz", "tree (default), splits frozen after 127,000 roots"),
        ("tree_ml8_poker_frz", "tree, min-leaf 8 + poker, splits frozen after 127,000 roots"),
        ("tree_inh051", "tree, inherit regret 0.5 + avg 1"), ("tree_inh11", "tree, inherit regret 1 + avg 1"),
        ("tree_s2", "tree (default), training seed 2"), ("tree_s3", "tree (default), training seed 3"),
        ("tree_ml8_s2", "tree, min-leaf 8, training seed 2"), ("tree_ml8_s3", "tree, min-leaf 8, training seed 3"),
        ("tree_ml8_poker_b1_s2", "tree, min-leaf 8 + poker, judgment budget 1.0, training seed 2"),
        ("tree_ml8_poker_b1_s3", "tree, min-leaf 8 + poker, judgment budget 1.0, training seed 3"),
        ("k8", "k-means 8 (matched table count)"), ("k32", "k-means 32 (matched table count)"),
        ("k64", "k-means 64 (matched table count)"),
        ("k256_s2", "k-means 256, training seed 2"), ("k256_s3", "k-means 256, training seed 3"),
        ("k256", "k-means 256 (baseline)"), ("ctx", "context (no cards)")]
snaps = {5: 63000, 6: 127000, 7: 255000, 8: 511000, 9: 1023000, 10: 2047000}
def ev(d, k, pol):
    f = f"{D}/eval_{d}_{k}_{pol}.json"
    if not os.path.exists(f) or os.path.getsize(f) == 0: return None
    return json.load(open(f))
def cpu(d, k):
    p = f"{D}/{d}/snapshots.csv"
    if not os.path.exists(p): return None
    for r in csv.DictReader(open(p)):
        if r["kind"] == "epoch" and int(r["epoch"]) == k: return float(r["train_cpu_seconds"]), int(r["buckets"])
    return None
print("| arm | roots | tables | training CPU s | LBR average policy (± se) | ratio to k-means 256 (same training seed) | LBR current policy (± se) | ratio |")
print("|---|---:|---:|---:|---:|---:|---:|---:|")
for k, roots in snaps.items():
    base = {pol: ev("k256", k, pol) for pol in ("average", "current")}
    for d, name in arms:
        c = cpu(d, k)
        if c is None: continue  # the run did not reach this budget
        cells = []
        for pol in ("average", "current"):
            e = ev(d, k, pol)
            if e is None: cells += ["missing", ""]; continue
            sfx = d[-3:] if d[-3:] in ("_s2", "_s3") else ""   # the baseline of the same training seed
            b = ev("k256" + sfx, k, pol)
            ratio = f"{e['lbr_ante'] / b['lbr_ante']:.2f}" if b and b["lbr_ante"] > 0 else ("n/a (baseline LBR <= 0)" if b else "missing baseline")
            cells += [f"{e['lbr_ante']:.3f} ± {e['lbr_se']:.3f}", ratio]
        print(f"| {name} | {roots:,} | {c[1]:,} | {c[0]:.0f} | " + " | ".join(cells) + " |")
